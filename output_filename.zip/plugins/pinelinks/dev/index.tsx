//import React from 'react';
import { createDevApp } from '@backstage/dev-utils';
import { pinelinksPlugin } from '../src/plugin';
//import { PinelinksPage } from '../src/PinelinksPage'; // Import the missing component

createDevApp()
  .registerPlugin(pinelinksPlugin)
  // .addPage({
  //   element: <pinelinksPlugin />,
  //   title: 'Root Page',
  //   path: '/pinelinks',
  // })
  .render();
