import { createPlugin } from '@backstage/core-plugin-api';

export const pinelinksPlugin = createPlugin({
  id: 'pinelinks',
  // Possibly define routes for other components that are actually pages
});

// No routable extension for FloatingButton if it's meant to be global
export { FloatingButton } from './components/FloatingButton';
