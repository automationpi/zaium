import React, { useEffect, useState } from 'react';
import Popover from '@material-ui/core/Popover';
import Typography from '@material-ui/core/Typography';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import { makeStyles } from '@material-ui/core/styles';
import Tooltip from '@material-ui/core/Tooltip';
import Button from '@material-ui/core/Button';
import HelpIcon from '@material-ui/icons/Help';
import { ConfigReader, createApiFactory, configApiRef } from '@backstage/core-plugin-api';

const config = new ConfigReader({
    pinelinks: [
        { id: "dashboard", title: "Dashboard", icon: "dashboard", url: "/dashboard" },
        // other links
    ],
});
const apis = ApiRegistry.from([
    createApiFactory(configApiRef, config),
]);

console.log('Links Config:', linksConfig);

interface Link {
    id: string;
    title: string;
    icon: string;
    url: string;
}

const useStyles = makeStyles((theme) => ({
    fab: {
        position: 'fixed',
        bottom: theme.spacing(3),
        right: theme.spacing(3),
        zIndex: 1000,
        backgroundColor: theme.palette.primary.main,
        color: 'white',
        padding: '0 20px',
        textTransform: 'none',
        '&:hover': {
            backgroundColor: theme.palette.primary.dark,
        },
        display: 'flex',
        alignItems: 'center',
        height: 48,
    },
    popover: {
        padding: theme.spacing(0),
        border: '1px solid #ddd',
        borderRadius: theme.shape.borderRadius,
        boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
        overflow: 'hidden',
    },
}));

export const FloatingButton: React.FC = () => {
    const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);
    const classes = useStyles();
    const configApi = useApi(configApiRef);
    const [links, setLinks] = useState<Link[]>([]);  // Move useState here, outside useEffect

    useEffect(() => {
        try {
            const linksConfig = configApi.getOptionalConfigArray('pinelinks');
            if (!linksConfig || linksConfig.length === 0) {
                console.error('No links configuration found or not visible.');
                return;
            }
            const newLinks = linksConfig.map(link => ({
                id: link.getString('id'),
                title: link.getString('title'),
                icon: link.getString('icon'),
                url: link.getString('url'),
            }));
            setLinks(newLinks);
        } catch (error) {
            console.error('Failed to load configuration for pinelinks:', error);
        }
    }, [configApi]);

    const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
        setAnchorEl(anchorEl ? null : event.currentTarget);
    };

    const open = Boolean(anchorEl);
    const id = open ? 'simple-popover' : undefined;

    return (
        <>
            <Tooltip title="Help & Issues" placement="left">
                <Button variant="contained" className={classes.fab} onClick={handleClick}>
                    <HelpIcon />
                    Help & Issues
                </Button>
            </Tooltip>
            <Popover
                id={id}
                open={open}
                anchorEl={anchorEl}
                onClose={() => setAnchorEl(null)}
                anchorOrigin={{
                    vertical: 'top',
                    horizontal: 'right',
                }}
                transformOrigin={{
                    vertical: 'bottom',
                    horizontal: 'right',
                }}
                className={classes.popover}
            >
                <Typography variant="h6">Navigation Links</Typography>
                <List>
                    {links.map((link, index) => (
                        <ListItem button key={index}>
                            <ListItemIcon>
                                <HelpIcon />  {/* Consider replacing this with dynamic icons if needed */}
                            </ListItemIcon>
                            <ListItemText primary={link.title} />
                        </ListItem>
                    ))}
                </List>
            </Popover>
        </>
    );
};
