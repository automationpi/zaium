import { pinelinksPlugin } from './plugin';

describe('pinelinks', () => {
  it('should export plugin', () => {
    expect(pinelinksPlugin).toBeDefined();
  });
});
